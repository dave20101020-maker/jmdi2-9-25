import Dashboard from './pages/Dashboard';
import Track from './pages/Track';
import Onboardingv2 from './pages/Onboardingv2';
import Analytics from './pages/Analytics';
import CoachSelect from './pages/CoachSelect';
import Coach from './pages/Coach';
import Profile from './pages/Profile';
import Sleep from './pages/Sleep';
import Diet from './pages/Diet';
import Exercise from './pages/Exercise';
import PhysicalHealth from './pages/PhysicalHealth';
import MentalHealth from './pages/MentalHealth';
import Finances from './pages/Finances';
import Social from './pages/Social';
import Spirituality from './pages/Spirituality';
import Onboarding from './pages/Onboarding';
import MyPlans from './pages/MyPlans';
import PlanDetail from './pages/PlanDetail';
import DailyProgress from './pages/DailyProgress';
import WeeklyReflection from './pages/WeeklyReflection';
import Upgrade from './pages/Upgrade';
import Goals from './pages/Goals';
import MyGrowth from './pages/MyGrowth';
import MoodTracker from './pages/MoodTracker';
import Habits from './pages/Habits';
import Friends from './pages/Friends';
import Milestones from './pages/Milestones';
import Connections from './pages/Connections';
import Feedback from './pages/Feedback';
import Meditation from './pages/Meditation';
import Achievements from './pages/Achievements';
import __Layout from './Layout.jsx';


export const PAGES = {
    "Dashboard": Dashboard,
    "Track": Track,
    "Onboardingv2": Onboardingv2,
    "Analytics": Analytics,
    "CoachSelect": CoachSelect,
    "Coach": Coach,
    "Profile": Profile,
    "Sleep": Sleep,
    "Diet": Diet,
    "Exercise": Exercise,
    "PhysicalHealth": PhysicalHealth,
    "MentalHealth": MentalHealth,
    "Finances": Finances,
    "Social": Social,
    "Spirituality": Spirituality,
    "Onboarding": Onboarding,
    "MyPlans": MyPlans,
    "PlanDetail": PlanDetail,
    "DailyProgress": DailyProgress,
    "WeeklyReflection": WeeklyReflection,
    "Upgrade": Upgrade,
    "Goals": Goals,
    "MyGrowth": MyGrowth,
    "MoodTracker": MoodTracker,
    "Habits": Habits,
    "Friends": Friends,
    "Milestones": Milestones,
    "Connections": Connections,
    "Feedback": Feedback,
    "Meditation": Meditation,
    "Achievements": Achievements,
}

export const pagesConfig = {
    mainPage: "Dashboard",
    Pages: PAGES,
    Layout: __Layout,
};