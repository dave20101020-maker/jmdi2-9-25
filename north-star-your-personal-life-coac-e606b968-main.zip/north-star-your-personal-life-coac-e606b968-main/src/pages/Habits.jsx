
import React, { useState, useEffect } from "react";
import { base44 } from "@/api/base44Client";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { useNavigate } from "react-router-dom";
import { createPageUrl, PILLARS, isHabitCompletedToday, calculateHabitStats, handleHabitCompletion, DEFAULT_HABIT_POINTS } from "../components/Utils";
import { ArrowLeft, Plus, Filter, Flame, TrendingUp, Calendar, Zap, Brain, Target, CheckCircle2 } from "lucide-react";
import { Button } from "@/components/ui/button";
import HabitCard from "../components/HabitCard";
import HabitCreator from "../components/HabitCreator";
import AIThinkingOverlay from "../components/AIThinkingOverlay";
import { toast } from "sonner";
import { format, differenceInDays } from "date-fns";

export default function Habits() {
  const navigate = useNavigate();
  const queryClient = useQueryClient();
  const [user, setUser] = useState(null);
  const [showCreator, setShowCreator] = useState(false);
  const [editingHabit, setEditingHabit] = useState(null);
  const [filterPillar, setFilterPillar] = useState("all");
  const [filterStatus, setFilterStatus] = useState("active");
  const [aiInsights, setAiInsights] = useState(null);
  const [loadingInsights, setLoadingInsights] = useState(false);

  useEffect(() => {
    async function getUser() {
      const currentUser = await base44.auth.me();
      setUser(currentUser);
    }
    getUser();
  }, []);

  const { data: habits = [], isLoading } = useQuery({
    queryKey: ['habits', user?.email],
    queryFn: () => base44.entities.Habit.filter({ userId: user?.email }, '-created_date', 200),
    enabled: !!user,
    initialData: []
  });

  const { data: moodEntries = [] } = useQuery({
    queryKey: ['moodEntries', user?.email],
    queryFn: () => base44.entities.MoodEntry.filter({ userId: user?.email }, '-timestamp', 100),
    enabled: !!user,
    initialData: []
  });

  const { data: goals = [] } = useQuery({
    queryKey: ['smartGoals', user?.email],
    queryFn: () => base44.entities.SmartGoal.filter({ created_by: user?.email }),
    enabled: !!user,
    initialData: []
  });

  const updateHabitMutation = useMutation({
    mutationFn: ({ id, data }) => base44.entities.Habit.update(id, data),
    onSuccess: (data) => {
      queryClient.invalidateQueries({ queryKey: ['habits', user?.email] });
      
      if (data.linkedGoalId) {
        queryClient.invalidateQueries({ queryKey: ['smartGoals', user?.email] });
      }
      if (data.linkedPlanId) {
        queryClient.invalidateQueries({ queryKey: ['lifePlans', user?.email] });
      }
    }
  });

  const deleteHabitMutation = useMutation({
    mutationFn: (id) => base44.entities.Habit.delete(id),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['habits', user?.email] });
      toast.success('Habit deleted successfully');
    }
  });

  const handleToggleComplete = async (habit) => {
    const isCompleting = !isHabitCompletedToday(habit);

    try {
      const updatedData = handleHabitCompletion(habit, isCompleting);

      await base44.entities.Habit.update(habit.id, updatedData);

      queryClient.invalidateQueries({ queryKey: ['habits', user?.email] });
      
      if (habit.linkedGoalId) {
        queryClient.invalidateQueries({ queryKey: ['smartGoals', user?.email] });
      }
      if (habit.linkedPlanId) {
        queryClient.invalidateQueries({ queryKey: ['lifePlans', user?.email] });
      }

      if (isCompleting) {
        toast.success(`✓ Habit completed! ${updatedData.streakCount} day streak`, {
          description: `+${DEFAULT_HABIT_POINTS} points earned`
        });
      } else {
        toast.info(`Habit uncompleted`);
      }

    } catch (error) {
      console.error('Error toggling habit:', error);
      toast.error('Failed to update habit', {
        description: 'Please try again'
      });
    }
  };

  const handleEdit = (habit) => {
    setEditingHabit(habit);
    setShowCreator(true);
  };

  const handleDelete = (habitId) => {
    if (confirm('Are you sure you want to delete this habit?')) {
      deleteHabitMutation.mutate(habitId);
    }
  };

  const handleTogglePause = (habit) => {
    updateHabitMutation.mutate({
      id: habit.id,
      data: { isActive: !habit.isActive }
    });
    toast.success(habit.isActive ? 'Habit paused' : 'Habit resumed');
  };

  const generateAIInsights = async () => {
    setLoadingInsights(true);

    try {
      const activeHabits = habits.filter(h => h.isActive);
      const stats = calculateHabitStats(habits);

      const recentMoods = moodEntries.slice(0, 14);
      const avgMood = recentMoods.length > 0
        ? Math.round(recentMoods.reduce((sum, e) => sum + e.moodScore, 0) / recentMoods.length)
        : 0;

      const prompt = `Analyze this habit tracking data and provide actionable insights:

Habit Formation Data:
- Active habits: ${stats.activeHabits}
- Completed today: ${stats.completedToday}/${stats.activeHabits}
- Average streak: ${Math.round(stats.totalStreak / Math.max(stats.activeHabits, 1))} days
- Total completions: ${activeHabits.reduce((sum, h) => sum + (h.totalCompletions || 0), 0)}
- Longest streak: ${Math.max(...activeHabits.map(h => h.bestStreak || 0), 0)} days
- Success rate: ${stats.avgCompletionRate}%

Habits by pillar:
${Object.entries(PILLARS).map(([id, p]) => {
  const pillarHabits = activeHabits.filter(h => h.pillar === id);
  return `- ${p.name}: ${pillarHabits.length} habits`;
}).join('\n')}

Mood Context:
- Average mood: ${avgMood}/100 (last 14 days)
- Mood entries: ${recentMoods.length}

Goals:
- Active goals: ${goals.filter(g => g.status === 'active').length}

Provide:
1. Success analysis (2-3 sentences about what's working well)
2. Improvement areas (2-3 specific recommendations)
3. Habit-mood correlation insight (1-2 sentences)
4. Suggestions for new habits (2-3 specific ideas)

Return ONLY valid JSON:
{
  "success": "Your success analysis here",
  "improvements": ["improvement 1", "improvement 2", "improvement 3"],
  "moodCorrelation": "Insight about mood and habits",
  "suggestions": ["suggestion 1", "suggestion 2", "suggestion 3"]
}`;

      const result = await base44.integrations.Core.InvokeLLM({
        prompt,
        response_json_schema: {
          type: "object",
          properties: {
            success: { type: "string" },
            improvements: {
              type: "array",
              items: { type: "string" }
            },
            moodCorrelation: { type: "string" },
            suggestions: {
              type: "array",
              items: { type: "string" }
            }
          }
        }
      });

      setAiInsights(result);
      setLoadingInsights(false);
      toast.success('Insights generated! 🧠', {
        description: 'AI analysis of your habit patterns is ready'
      });
    } catch (error) {
      console.error('Error generating insights:', error);
      setLoadingInsights(false);
      toast.error('Failed to generate insights', {
        description: 'Our AI is temporarily unavailable. Try again in a moment.'
      });
    }
  };

  // Filter habits
  const filteredHabits = habits.filter(h => {
    const pillarMatch = filterPillar === "all" || h.pillar === filterPillar;
    const statusMatch = filterStatus === "all" ||
                       (filterStatus === "active" && h.isActive) ||
                       (filterStatus === "paused" && !h.isActive);
    return pillarMatch && statusMatch;
  });

  // Stats
  const stats = calculateHabitStats(habits);

  if (isLoading) {
    return (
      <div className="min-h-screen flex items-center justify-center pb-20">
        <div className="text-center">
          <div className="w-16 h-16 mx-auto mb-4 rounded-full bg-[#D4AF37]/20 animate-pulse" />
          <p className="text-white/60">Loading habits...</p>
        </div>
      </div>
    );
  }

  return (
    <>
      <AIThinkingOverlay
        isVisible={loadingInsights}
        message="NorthStar is analyzing your habit patterns..."
      />

      <div className="min-h-screen pb-24 px-4 sm:px-6 pt-6">
        <div className="max-w-6xl mx-auto">
          {/* Header */}
          <div className="flex flex-col sm:flex-row items-start sm:items-center gap-4 mb-6">
            <button
              onClick={() => navigate(createPageUrl("MyGrowth"))}
              className="text-white/60 hover:text-white transition-colors"
            >
              <ArrowLeft className="w-6 h-6" />
            </button>
            <div className="flex-1">
              <h1 className="text-2xl md:text-3xl font-bold text-white flex items-center gap-2">
                <Zap className="w-6 h-6 md:w-7 md:h-7 text-[#D4AF37]" />
                Habit Tracker
              </h1>
              <p className="text-white/60 text-sm">Build sustainable daily practices</p>
            </div>
            <Button
              onClick={() => {
                setEditingHabit(null);
                setShowCreator(true);
              }}
              className="bg-gradient-to-r from-[#D4AF37] to-[#F4D03F] text-[#0A1628] font-bold w-full sm:w-auto"
              style={{ boxShadow: '0 0 20px rgba(212, 175, 55, 0.4)' }}
            >
              <Plus className="w-5 h-5 mr-2" />
              New Habit
            </Button>
          </div>

          {habits.length === 0 ? (
            /* Enhanced Empty State */
            <div className="text-center py-12 md:py-16">
              <div className="bg-white/5 border border-white/10 rounded-2xl p-8 md:p-12 max-w-lg mx-auto">
                {/* Animated Habit Loop Visual */}
                <div className="w-32 h-32 md:w-40 md:h-40 mx-auto mb-6" aria-hidden="true">
                  <svg viewBox="0 0 200 200" className="w-full h-full">
                    {/* Circular habit loop */}
                    <circle cx="100" cy="100" r="70" fill="none" stroke="#D4AF37" strokeWidth="3" opacity="0.3" strokeDasharray="10,5">
                      <animateTransform
                        attributeName="transform"
                        type="rotate"
                        from="0 100 100"
                        to="360 100 100"
                        dur="20s"
                        repeatCount="indefinite"
                      />
                    </circle>
                    
                    {/* Checkmarks around the circle */}
                    <g opacity="0.4">
                      <circle cx="100" cy="30" r="8" fill="#52B788" />
                      <text x="100" y="35" textAnchor="middle" fill="#fff" fontSize="12" fontWeight="bold">✓</text>
                      
                      <circle cx="170" cy="100" r="8" fill="#52B788" />
                      <text x="170" y="105" textAnchor="middle" fill="#fff" fontSize="12" fontWeight="bold">✓</text>
                      
                      <circle cx="100" cy="170" r="8" fill="#52B788" />
                      <text x="100" y="175" textAnchor="middle" fill="#fff" fontSize="12" fontWeight="bold">✓</text>
                    </g>
                    
                    {/* Central Zap icon */}
                    <circle cx="100" cy="100" r="25" fill="#D4AF37" opacity="0.2" />
                    <text x="100" y="110" textAnchor="middle" fill="#F4D03F" fontSize="40">⚡</text>
                  </svg>
                </div>
                
                <h2 className="text-2xl md:text-3xl font-bold text-white mb-3">Build Your First Habit</h2>
                <p className="text-white/70 mb-6 text-sm md:text-base px-4">
                  Small daily actions create lasting change. Start building a habit that supports your life goals.
                </p>
                
                <Button
                  onClick={() => setShowCreator(true)}
                  className="bg-gradient-to-r from-[#D4AF37] to-[#F4D03F] text-[#0A1628] font-bold mb-6"
                  style={{ boxShadow: '0 0 20px rgba(212, 175, 55, 0.5)' }}
                >
                  <Plus className="w-5 h-5 mr-2" />
                  Create Your First Habit
                </Button>
                
                {/* Habit Formation Tips */}
                <div className="bg-blue-500/10 border border-blue-500/30 rounded-xl p-4 md:p-6 text-left">
                  <h3 className="text-white font-bold mb-3 flex items-center gap-2">
                    <Zap className="w-5 h-5 text-blue-400" />
                    Habit Formation Tips
                  </h3>
                  <ul className="space-y-2 text-sm text-white/80">
                    <li className="flex items-start gap-2">
                      <span className="text-blue-400 flex-shrink-0">1.</span>
                      <span><strong>Start small:</strong> Choose simple, achievable daily actions</span>
                    </li>
                    <li className="flex items-start gap-2">
                      <span className="text-blue-400 flex-shrink-0">2.</span>
                      <span><strong>Link to existing routines:</strong> Stack new habits onto established ones</span>
                    </li>
                    <li className="flex items-start gap-2">
                      <span className="text-blue-400 flex-shrink-0">3.</span>
                      <span><strong>Track consistently:</strong> Build momentum with daily check-ins</span>
                    </li>
                    <li className="flex items-start gap-2">
                      <span className="text-blue-400 flex-shrink-0">4.</span>
                      <span><strong>Be patient:</strong> It takes 21-66 days to form a new habit</span>
                    </li>
                  </ul>
                </div>
              </div>
            </div>
          ) : (
            <>
              {/* Stats */}
              <div className="grid grid-cols-2 md:grid-cols-4 gap-3 md:gap-4 mb-6">
                <div className="bg-[#1a1f35] border border-white/20 rounded-xl p-3 md:p-4">
                  <div className="flex items-center gap-2 mb-1">
                    <CheckCircle2 className="w-4 h-4 text-green-400" />
                    <div className="text-white/70 text-xs md:text-sm font-medium">Today</div>
                  </div>
                  <div className="text-2xl md:text-3xl font-bold text-green-400">{stats.completedToday}</div>
                  <div className="text-xs text-white/60">of {stats.activeHabits} active</div>
                </div>

                <div className="bg-[#1a1f35] border border-white/20 rounded-xl p-3 md:p-4">
                  <div className="flex items-center gap-2 mb-1">
                    <Flame className="w-4 h-4 text-orange-400" />
                    <div className="text-white/70 text-xs md:text-sm font-medium">Streaks</div>
                  </div>
                  <div className="text-2xl md:text-3xl font-bold text-orange-400">{stats.totalStreak}</div>
                  <div className="text-xs text-white/60">days</div>
                </div>

                <div className="bg-[#1a1f35] border border-white/20 rounded-xl p-3 md:p-4">
                  <div className="flex items-center gap-2 mb-1">
                    <Target className="w-4 h-4 text-[#4CC9F0]" />
                    <div className="text-white/70 text-xs md:text-sm font-medium">Active</div>
                  </div>
                  <div className="text-2xl md:text-3xl font-bold text-[#4CC9F0]">{stats.activeHabits}</div>
                  <div className="text-xs text-white/60">habits</div>
                </div>

                <div className="bg-[#1a1f35] border border-white/20 rounded-xl p-3 md:p-4">
                  <div className="flex items-center gap-2 mb-1">
                    <TrendingUp className="w-4 h-4 text-[#D4AF37]" />
                    <div className="text-white/70 text-xs md:text-sm font-medium">Success</div>
                  </div>
                  <div className="text-2xl md:text-3xl font-bold text-[#D4AF37]">{stats.avgCompletionRate}%</div>
                  <div className="text-xs text-white/60">rate</div>
                </div>
              </div>

              {/* Filters */}
              <div className="flex flex-col sm:flex-row gap-3 md:gap-4 mb-6">
                <div className="flex items-center gap-2 flex-1">
                  <Filter className="w-4 h-4 text-white/60 hidden sm:block" />
                  <select
                    value={filterPillar}
                    onChange={(e) => setFilterPillar(e.target.value)}
                    className="w-full bg-[#1a1f35] border border-white/20 rounded-lg px-3 py-2 text-white text-sm font-bold"
                  >
                    <option value="all">All Pillars</option>
                    {Object.entries(PILLARS).map(([id, pillar]) => (
                      <option key={id} value={id}>{pillar.icon} {pillar.name}</option>
                    ))}
                  </select>
                </div>

                <div className="flex gap-2">
                  {['active', 'paused', 'all'].map(status => (
                    <button
                      key={status}
                      onClick={() => setFilterStatus(status)}
                      className={`flex-1 sm:flex-none px-3 md:px-4 py-2 rounded-lg font-bold transition-all capitalize text-sm ${
                        filterStatus === status
                          ? 'bg-[#D4AF37] text-[#0A1628]'
                          : 'bg-[#1a1f35] border border-white/20 text-white hover:bg-white/5'
                      }`}
                    >
                      {status}
                    </button>
                  ))}
                </div>
              </div>

              {/* AI Insights */}
              {habits.length >= 3 && (
                <div className="bg-[#1a1f35] border border-white/20 rounded-2xl p-4 md:p-6 mb-6">
                  <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-3 mb-4">
                    <h2 className="text-lg md:text-xl font-bold text-white flex items-center gap-2">
                      <Brain className="w-5 h-5 md:w-6 md:h-6 text-[#F4D03F]" />
                      AI Habit Insights
                    </h2>
                    <Button
                      onClick={generateAIInsights}
                      disabled={loadingInsights}
                      size="sm"
                      className="bg-[#F4D03F]/20 hover:bg-[#F4D03F]/30 text-[#F4D03F] font-bold w-full sm:w-auto"
                    >
                      {loadingInsights ? 'Analyzing...' : 'Generate Insights'}
                    </Button>
                  </div>

                  {aiInsights ? (
                    <div className="space-y-4">
                      <div className="bg-green-500/10 border border-green-500/30 rounded-xl p-4">
                        <h4 className="text-white font-bold mb-2">✓ What's Working</h4>
                        <p className="text-white/80 text-sm">{aiInsights.success}</p>
                      </div>

                      <div className="bg-blue-500/10 border border-blue-500/30 rounded-xl p-4">
                        <h4 className="text-white font-bold mb-2">📈 Areas for Improvement</h4>
                        <ul className="space-y-1">
                          {aiInsights.improvements.map((imp, idx) => (
                            <li key={idx} className="text-white/80 text-sm flex items-start gap-2">
                              <span className="text-blue-400 flex-shrink-0">•</span>
                              <span>{imp}</span>
                            </li>
                          ))}
                        </ul>
                      </div>

                      <div className="bg-purple-500/10 border border-purple-500/30 rounded-xl p-4">
                        <h4 className="text-white font-bold mb-2">🧠 Mood-Habit Connection</h4>
                        <p className="text-white/80 text-sm">{aiInsights.moodCorrelation}</p>
                      </div>

                      <div className="bg-[#D4AF37]/10 border border-[#D4AF37]/30 rounded-xl p-4">
                        <h4 className="text-white font-bold mb-2">💡 Suggested New Habits</h4>
                        <ul className="space-y-1">
                          {aiInsights.suggestions.map((sug, idx) => (
                            <li key={idx} className="text-white/80 text-sm flex items-start gap-2">
                              <span className="text-[#F4D03F] flex-shrink-0">•</span>
                              <span>{sug}</span>
                            </li>
                          ))}
                        </ul>
                      </div>
                    </div>
                  ) : (
                    <div className="text-center py-6">
                      <p className="text-white/60 text-sm">
                        Click "Generate Insights" to get AI-powered habit formation analysis
                      </p>
                    </div>
                  )}
                </div>
              )}

              {/* Habits Grid */}
              {filteredHabits.length === 0 ? (
                <div className="text-center py-12 md:py-16">
                  <div className="bg-white/5 border border-white/10 rounded-2xl p-8 md:p-12 max-w-md mx-auto">
                    <Filter className="w-12 h-12 md:w-16 md:h-16 mx-auto mb-4 text-white/40" />
                    <h2 className="text-xl md:text-2xl font-bold text-white mb-2">No Habits Match Filters</h2>
                    <p className="text-white/70 mb-6 text-sm md:text-base">
                      Try adjusting your filters to see more habits
                    </p>
                    <Button
                      onClick={() => {
                        setFilterPillar("all");
                        setFilterStatus("active");
                      }}
                      variant="outline"
                      className="border-white/20 text-white hover:bg-white/10"
                    >
                      Clear Filters
                    </Button>
                  </div>
                </div>
              ) : (
                <div className="grid md:grid-cols-2 gap-4 md:gap-6">
                  {filteredHabits.map(habit => (
                    <HabitCard
                      key={habit.id}
                      habit={habit}
                      onToggleComplete={() => handleToggleComplete(habit)}
                      onEdit={() => handleEdit(habit)}
                      onDelete={() => handleDelete(habit.id)}
                      onTogglePause={() => handleTogglePause(habit)}
                    />
                  ))}
                </div>
              )}
            </>
          )}
        </div>

        {showCreator && (
          <HabitCreator
            onClose={() => {
              setShowCreator(false);
              setEditingHabit(null);
            }}
            onSuccess={() => {
              setShowCreator(false);
              setEditingHabit(null);
              queryClient.invalidateQueries({ queryKey: ['habits', user?.email] });
            }}
            initialHabit={editingHabit}
            user={user}
          />
        )}
      </div>
    </>
  );
}
